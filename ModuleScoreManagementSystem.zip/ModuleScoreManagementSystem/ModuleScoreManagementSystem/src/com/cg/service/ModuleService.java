package com.cg.service;

import java.util.List;

import com.cg.dto.AssessmentScore;
import com.cg.exception.ScoreException;

public interface ModuleService {
	List<Long> getTraineeIds() throws ScoreException;
	public AssessmentScore addDetails(AssessmentScore assess) throws ScoreException;
	public double calculateTotal(int mpt,int mtt, int assignment) throws ScoreException;
	public int calculateGrade(double total) throws ScoreException;
	public int checkAdded(long traineeid,String module) throws ScoreException;
}
