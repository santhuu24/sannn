package com.cg.service;

import java.util.List;

import com.cg.dao.ModuleDAO;
import com.cg.dao.ModuleDAOImpl;
import com.cg.dto.AssessmentScore;
import com.cg.exception.ScoreException;

public class ModuleServiceImpl implements ModuleService{
	ModuleDAO dao= new ModuleDAOImpl();
	@Override
	public List<Long> getTraineeIds() throws ScoreException {
		return dao.getTraineeIds();
	}

	@Override
	public AssessmentScore addDetails(AssessmentScore assess)
			throws ScoreException {
		return dao.addDetails(assess);
	}

	@Override
	public double calculateTotal(int mpt, int mtt, int assignment)
			throws ScoreException {
		double total=(mpt)+(mtt)+(assignment);//total ranges (0-100)= mpt ranging 0-70,mtt ranging 0-15,ass ranging 0-15
//return null;
	return total;
	}

	@Override
	public int calculateGrade(double total) throws ScoreException {
		int grade=0;
		if(total>=0 && total<50)
			grade=0;
		else if(total>=50 && total<60)
			grade=1;
		else if(total>=60 && total<70)
			grade=2;
		else if(total>=70 && total<80)
			grade=3;
		else if(total>=80 && total<90)
			grade=4;
		else if(total>=90 && total<=100)
			grade=5;
		return grade;
	}

	@Override
	public int checkAdded(long traineeid, String module) throws ScoreException {
		// TODO Auto-generated method stub
		return dao.checkAdded(traineeid, module);
	}

}
