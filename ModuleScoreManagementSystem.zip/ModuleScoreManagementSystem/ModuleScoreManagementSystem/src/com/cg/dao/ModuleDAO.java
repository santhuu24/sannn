package com.cg.dao;

import java.util.List;

import com.cg.dto.AssessmentScore;
import com.cg.exception.ScoreException;



public interface ModuleDAO {
	List<Long> getTraineeIds() throws ScoreException;
	public AssessmentScore addDetails(AssessmentScore assess) throws ScoreException;
	public int checkAdded(long traineeid,String module) throws ScoreException;
}
