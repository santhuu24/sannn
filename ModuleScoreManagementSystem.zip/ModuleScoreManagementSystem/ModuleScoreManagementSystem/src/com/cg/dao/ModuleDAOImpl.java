package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.dto.AssessmentScore;
import com.cg.exception.ScoreException;

public class ModuleDAOImpl implements ModuleDAO{
	Connection conn;
	@Override
	public List<Long> getTraineeIds() throws ScoreException {
		List<Long> traineelist=new ArrayList<Long>();
		conn=DBUtil.getConnection();
		String sql="SELECT trainee_id FROM trainees";
		try{
		PreparedStatement ps=conn.prepareStatement(sql);
		ResultSet rs=ps.executeQuery();
		while(rs.next()){
			traineelist.add(rs.getLong("trainee_id"));
		}
		return traineelist;
		}catch(SQLException e){
			throw new ScoreException("Problem in fetching list"+e.getMessage());
		}	
	}

	@Override
	public AssessmentScore addDetails(AssessmentScore assess)
			throws ScoreException {
		String sql="insert into AssessmentScore values(?,?,?,?,?,?,?)";
		//AssessmentScore ass=new AssessmentScore();
		conn=DBUtil.getConnection();
		try {
			PreparedStatement pst = conn.prepareStatement(sql);
			
	
				pst.setLong(1, assess.getTrainee_id());
				pst.setString(2, assess.getModule_name());
				pst.setInt(3, assess.getMpt());
				pst.setInt(4, assess.getMtt());
				pst.setInt(5, assess.getAss_marks());
				pst.setInt(6, assess.getTotalmarks());
				pst.setInt(7, assess.getGrade());
			
				ResultSet rs=pst.executeQuery();
			
			
		} catch (SQLException e) {
			throw new ScoreException(e.getMessage());
		}
		return  assess;
	}

	@Override
	public int checkAdded(long traineeid, String module) throws ScoreException {
		String sql="select mpt from AssessmentScore where trainee_id=? and module_name=?";
		conn=DBUtil.getConnection();
		try {
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setLong(1, traineeid);
			pst.setString(2, module);
			int rs= pst.executeUpdate();
			return rs;
			
		} catch (SQLException e) {
			throw new ScoreException("Problem in fetching mobile data"+e.getMessage());
		}
		
	}


}
