package com.cg.dto;

public class TraineeBean {
	private long  trainee_id;
	private String trainee_name;
	public TraineeBean() {
		// TODO Auto-generated constructor stub
	}
	public TraineeBean(long trainee_id, String trainee_name) {
		super();
		this.trainee_id = trainee_id;
		this.trainee_name = trainee_name;
	}
	public long getTrainee_id() {
		return trainee_id;
	}
	public void setTrainee_id(long trainee_id) {
		this.trainee_id = trainee_id;
	}
	public String getTrainee_name() {
		return trainee_name;
	}
	public void setTrainee_name(String trainee_name) {
		this.trainee_name = trainee_name;
	}
	
}
