package com.cg.dto;

public class AssessmentScore {
	private long  trainee_id;
	private String module_name;
	private int mpt;
	private int mtt;
	private int ass_marks;
	private int totalmarks;
	private int grade;
	public AssessmentScore() {
		// TODO Auto-generated constructor stub
	}
	public AssessmentScore(long trainee_id, String module_name, int mpt,
			int mtt, int ass_marks, int totalmarks, int grade) {
		super();
		this.trainee_id = trainee_id;
		this.module_name = module_name;
		this.mpt = mpt;
		this.mtt = mtt;
		this.ass_marks = ass_marks;
		this.totalmarks = totalmarks;
		this.grade = grade;
	}
	public long getTrainee_id() {
		return trainee_id;
	}
	public void setTrainee_id(long trainee_id) {
		this.trainee_id = trainee_id;
	}
	public String getModule_name() {
		return module_name;
	}
	public void setModule_name(String module_name) {
		this.module_name = module_name;
	}
	public int getMpt() {
		return mpt;
	}
	public void setMpt(int mpt) {
		this.mpt = mpt;
	}
	public int getMtt() {
		return mtt;
	}
	public void setMtt(int mtt) {
		this.mtt = mtt;
	}
	public int getAss_marks() {
		return ass_marks;
	}
	public void setAss_marks(int ass_marks) {
		this.ass_marks = ass_marks;
	}
	public int getTotalmarks() {
		return totalmarks;
	}
	public void setTotalmarks(int totalmarks) {
		this.totalmarks = totalmarks;
	}
	public int getGrade() {
		return grade;
	}
	public void setGrade(int grade) {
		this.grade = grade;
	}
	
}
