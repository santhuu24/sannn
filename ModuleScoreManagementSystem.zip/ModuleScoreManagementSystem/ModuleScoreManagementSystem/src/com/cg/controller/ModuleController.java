package com.cg.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.dto.AssessmentScore;
import com.cg.exception.ScoreException;
import com.cg.service.ModuleService;
import com.cg.service.ModuleServiceImpl;
@WebServlet(urlPatterns = { "/ModuleController", "/addDetails" })
public class ModuleController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			ModuleService service = new ModuleServiceImpl();
			String url = request.getServletPath();
			String target = "";
			switch (url) {
			case "/ModuleController":		
				try {
					List<Long> clist = service.getTraineeIds();
					HttpSession session=request.getSession(true);// here, i have used session,so that this detail can also be assessed through error page.
					session.setAttribute("clist", clist);
					target = "AddAssessment.jsp";
				} catch (ScoreException e) {
					String error = e.getMessage();
					request.setAttribute("error", error);
					target = "Error.jsp";
				}
				break;
			case "/addDetails":
				long traineeid=Long.parseLong(request.getParameter("tid"));
				String module=request.getParameter("mod");
				int mpt=Integer.parseInt(request.getParameter("mpt"));
				int mtt=Integer.parseInt(request.getParameter("mtt"));
				int assignment=Integer.parseInt(request.getParameter("ass"));
				try {
					double total = service.calculateTotal(mpt, mtt, assignment);
					int grade=service.calculateGrade(total);
					AssessmentScore ass=new AssessmentScore();
					ass.setTrainee_id(traineeid);
					ass.setModule_name(module);
					ass.setMpt(mpt);
					ass.setMtt(mtt);
					ass.setAss_marks(assignment);
					ass.setTotalmarks((int)total);
					ass.setGrade(grade);
					int check=service.checkAdded(traineeid, module);
					if(check==0){
					AssessmentScore alist=service.addDetails(ass);
					request.setAttribute("alist", alist);
					target = "ModuleResult.jsp";}
					else{
						
						response.sendRedirect("http://localhost:8081/ModuleScoreManagementSystem/Error.jsp");
					}
				}catch (ScoreException e) {
					String error = e.getMessage();
					request.setAttribute("error", error);
					target = "Error.jsp";
				}
			break;
			}
			RequestDispatcher disp = request.getRequestDispatcher(target);
			disp.forward(request, response);
		}// end of do post
}//end of class
